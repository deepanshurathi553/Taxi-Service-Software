import java.util.*;
import java.util.LinkedList;
public class PositionList{

	Myset<Position> ridam = new Myset<Position>();
	public PositionList(){

	}
	public void addPosition(String xx){
		Position newx = new Position(xx);
		ridam.addElement(newx);
	}

	public Position findPosition(String x){
		for(int i=0;i<ridam.getSizeSet();i++){
			if(ridam.getElement(i).thisPosition.equals(x)){
				return ridam.getElement(i);
			}
		}
		return null;
	}
	public Myset<Position> sortedAlphabetically(){
		LinkedList<String> list = new LinkedList<String>();
    	for(int y=0;y<ridam.getSizeSet();y++){
			if(!list.contains(ridam.getElement(y).thisPosition))
			list.add(ridam.getElement(y).thisPosition);
		}
		//System.out.println("here1"+list.size());
    	Collections.sort(list);
    	Myset<Position> cv = new Myset<Position>();
    	for(int i=0;i<list.size();i++){
    	//	System.out.println("here" + list.get(i));
    		cv.addElement(findPosition(list.get(i)));
    	}
    	return cv;
	}
}