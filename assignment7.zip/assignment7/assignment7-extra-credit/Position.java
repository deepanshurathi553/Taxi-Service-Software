import java.util.*;
public class Position{
	String thisPosition = new String();
	public Position(String x){
		thisPosition = x;
	}
}