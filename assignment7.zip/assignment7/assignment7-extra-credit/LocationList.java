import java.util.*;

public class LocationList{
	
	Myset<Location> setOfAllLocations = new Myset<Location>();

	public LocationList(){

	}
	public void addLocation(Location a){
		if(!setOfAllLocations.isMember(a)){
			setOfAllLocations.addElement(a);
		}
	}
	public Location findLocation(Position a){
		for(int i=0;i<setOfAllLocations.getSizeSet();i++){
			if(setOfAllLocations.getElement(i).vertexStart.thisPosition.equals(a.thisPosition) || setOfAllLocations.getElement(i).vertexEnd.thisPosition.equals(a.thisPosition)){
				return setOfAllLocations.getElement(i);
			}
		}
		return null;
	}
	public Location findLocationNew(Position a, Position b, int o, int gc){
		//System.out.println(a.thisPosition);
		//System.out.println(b.thisPosition);
		for(int i=0;i<setOfAllLocations.getSizeSet();i++){
			if(setOfAllLocations.getElement(i).vertexStart.thisPosition.equals(a.thisPosition)){
		//		System.out.println("idhar");
				if(setOfAllLocations.getElement(i).vertexEnd.thisPosition.equals(b.thisPosition)){
					if(setOfAllLocations.getElement(i).distance == o){
		//				System.out.println("hey!");
						return setOfAllLocations.getElement(i);
					}
				}
			}
			if(setOfAllLocations.getElement(i).vertexEnd.thisPosition.equals(a.thisPosition)){
		//		System.out.println("udhar");
				if(setOfAllLocations.getElement(i).vertexStart.thisPosition.equals(b.thisPosition)){
					int bn = gc;
					//System.out.println(bn);
					if(setOfAllLocations.getElement(i).distance == bn-o){
		//				System.out.println("hello!");
						return setOfAllLocations.getElement(i);
					}
				}
			}

		}
		return null;
	}
}