import java.util.*;

public class AlphaOrder{
	
}