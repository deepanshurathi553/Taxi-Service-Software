import java.util.*;
public class TaxiService{
	
	public TaxiService(){
		
	}
	EdgeList edgeSet = new EdgeList();
	PositionList positionSet = new PositionList();
	//PathList pathSet = new PathList();
	LocationList locationSet = new LocationList();
	TaxiList taxiSet = new TaxiList();
	ShortPath pathSet = new ShortPath(positionSet, edgeSet);
	public void addEdgeToMap(String x, String y, int t){
		if(positionSet.findPosition(x) != null &&positionSet.findPosition(y)!= null){
			edgeSet.addEdge(positionSet.findPosition(x), positionSet.findPosition(y), t);
		}
		else{
			if(positionSet.findPosition(x)==null){
				positionSet.addPosition(x);
			}
			if(positionSet.findPosition(y)==null){
				positionSet.addPosition(y);
			}
			edgeSet.addEdge(positionSet.findPosition(x), positionSet.findPosition(y), t);
		}
	}
	public void addLocations(Edge x){		
		for(int j=0;j<x.time;j++){
			Location a = new Location(x.start, x.end, j);
			if(!locationSet.setOfAllLocations.set1.list1.contains(a))
			locationSet.addLocation(a);
			//System.out.println(locationSet.setOfAllLocations.getSizeSet());
		}
	}
	public Position getNearestVertex(Taxi a){
		Edge c = edgeSet.getEdge(a.currLocation.vertexStart, a.currLocation.vertexEnd);
		int h = c.time;
		//System.out.println(h);
		if(a.currLocation.distance<h/2){
			return a.currLocation.vertexStart;
		}
		if(a.currLocation.distance>h/2){
			return a.currLocation.vertexEnd;
		}
		if(a.currLocation.distance==h/2){
			Myset<Position> re = new Myset<Position>();
			re = positionSet.sortedAlphabetically();
			for(int u=0;u<re.getSizeSet();u++){
				if(re.getElement(u).thisPosition.equals(a.currLocation.vertexStart.thisPosition))return a.currLocation.vertexStart;
				if(re.getElement(u).thisPosition.equals(a.currLocation.vertexEnd.thisPosition))return a.currLocation.vertexEnd;
			}
		}
		return null;	
	}
	public int getIDofThisPosition(Position a){
		Myset<Position> re = new Myset<Position>();
			re = positionSet.sortedAlphabetically();
			for(int u=0;u<re.getSizeSet();u++){
				//System.out.println(re.getElement(u).thisPosition);
				//System.out
				if(re.getElement(u).thisPosition.equals(a.thisPosition))return u;
				//if(re.getElement(u).thisPosition.equals(a.thisPosition))return u;
			}
		return Integer.MAX_VALUE;	
	}
	public Position getNewDestination(Taxi a){
		Position x = getNearestVertex(a);
		//System.out.println("bbbbbb"+x.thisPosition);
		int id = getIDofThisPosition(x);
		//System.out.println(id);
		int c = positionSet.ridam.getSizeSet();
		//System.out.println(c);
		int newid=(id+1)%c;
		//System.out.println(newid);
		Myset<Position> re = new Myset<Position>();
		re = positionSet.sortedAlphabetically();
		//System.out.println(re.getElement(newid).thisPosition);
		if(!re.getElement(newid).thisPosition.equals(a.currPosition.thisPosition))
			return re.getElement(newid);
		else{
			return re.getElement(id);
		} 	
	}
	public void addTaxiToMap(String x, String y){
		Position p = positionSet.findPosition(y);
		Location xi = locationSet.findLocation(p);
		Taxi ch = new Taxi(x, p, 0, xi);
		if(p!=null){
			taxiSet.addTaxi(ch);
		}
		else{
			System.out.println("No Such Position Exist");
		}
	}
	public void kool(Taxi a, Position n, Location m, int raju){
		int jk=0;
		while(jk<raju){
			Position mk = getNewDestination(a);
			//System.out.println("nn"+a.currPosition.thisPosition);
			//System.out.println("mm"+mk.thisPosition);
			pathSet.mainFunction(a.currPosition);
			//Edge c = pathSet.getPath(a.currPosition, mk);
			int gc = pathSet.getShortestDistance(mk);
			if((raju-jk)>=gc){
				jk+=gc;
				a.currLocation = locationSet.findLocation(mk);
				a.currPosition = mk;				
			}
			if((raju-jk)<gc){
				int ck = raju-jk;
				jk = raju;
				a.currLocation = locationSet.findLocationNew(a.currPosition, mk, ck, gc);
			}
		}
	}
	public void movingTheTaxis(int raju){
		for(int y=0;y<taxiSet.setOfAllTaxis.getSizeSet();y++){
			//System.out.println(taxiSet.setOfAllTaxis.getElement(y).currPosition.thisPosition);
			//System.out.println(getNewDestination(taxiSet.setOfAllTaxis.getElement(y)).thisPosition);
			Position a = taxiSet.setOfAllTaxis.getElement(y).currPosition;
			Location b = taxiSet.setOfAllTaxis.getElement(y).currLocation;
			kool(taxiSet.setOfAllTaxis.getElement(y), a, b, raju);
			//System.out.println(taxiSet.setOfAllTaxis.getElement(y).currPosition.thisPosition);
			//System.out.println(taxiSet.setOfAllTaxis.getElement(y).currLocation.distance);
		}
	}
	int k=0;
	public void performAction(String actionMessage){
		System.out.println("action to be performed: " + actionMessage);
		String[] tmp = actionMessage.split(" ");
		if(tmp[0].equals("edge")){
			int timegiven = Integer.parseInt(tmp[3]);
			addEdgeToMap(tmp[1], tmp[2], timegiven);
			System.out.println("Edge added : " + tmp[1] + "--" + tmp[2] + " distance = " + tmp[3]);
			addLocations(edgeSet.bir.getElement(k));
			k++;
			//System.out.println(locationSet.setOfAllLocations.getSizeSet());
		}
		if(tmp[0].equals("taxi")){
			addTaxiToMap(tmp[1], tmp[2]);
			System.out.println("Taxi " + tmp[1] + " added at " + tmp[2]);
			//System.out.println(edgeSet.getAllEdgesThroughThisVertex(positionSet.findPosition("AIIMS")).getSizeSet());
			//System.out.println(edgeSet.getAllEdgesThroughThisVertex(positionSet.findPosition("iitmaingate")).getSizeSet());
			//System.out.println(taxiSet.setOfAllTaxis.getSizeSet());
		}
		if(tmp[0].equals("customer")){
			int bc = Integer.parseInt(tmp[7]);
			movingTheTaxis(bc);
		}

		/*
		if(tmp[0].equals("customer")){
			/*if(positionSet.findPosition(tmp[1])!=null && positionSet.findPosition(tmp[2])!=null){
			addPaths(tmp[1], tmp[2]);
			for(int i=0;i<taxiSet.setOfAllTaxis.getSizeSet();i++){
				addPaths(taxiSet.setOfAllTaxis.getElement(i).currPosition.thisPosition, tmp[1]);
			}
			allotTimeToEachPath();
			Myset<Taxi> availableTaxis = new Myset<Taxi>();
			for(int i=0;i<taxiSet.setOfAllTaxis.getSizeSet();i++){
				if(taxiSet.setOfAllTaxis.getElement(i).availability == 0){
					availableTaxis.addElement(taxiSet.setOfAllTaxis.getElement(i));
				}
			}
			System.out.println("Available Taxis :");
			for(int j=0;j<availableTaxis.getSizeSet();j++){
				if(!availableTaxis.getElement(j).currPosition.thisPosition.equals(tmp[1])){
					Path x = returnMinPath(availableTaxis.getElement(j).currPosition.thisPosition, tmp[1]);
					Myset<Position> c = new Myset<Position>();
					c.addElement(availableTaxis.getElement(j).currPosition);
					for(int p=0;p<x.edgeSetOfThisPath.getSizeSet();p++){
						if(p>=1){
							if(c.isMember(x.edgeSetOfThisPath.getElement(p).start)){
								c.addElement(x.edgeSetOfThisPath.getElement(p).end);
							}
							if(c.isMember(x.edgeSetOfThisPath.getElement(p).end)){
								c.addElement(x.edgeSetOfThisPath.getElement(p).start);
							}
						}
						else{
						if(!c.isMember(x.edgeSetOfThisPath.getElement(p).start)){
							c.addElement(x.edgeSetOfThisPath.getElement(p).start);
						}
						if(!c.isMember(x.edgeSetOfThisPath.getElement(p).end)){
							c.addElement(x.edgeSetOfThisPath.getElement(p).end);
						}
						}
					}
					System.out.print("Path of Taxi " + availableTaxis.getElement(j).taxiName + " : " );
					for(int l=0;l<c.getSizeSet()-1;l++){
						System.out.print(c.getElement(l).thisPosition + ", ");
					}
					System.out.println(tmp[1] + ". " + "Time Taken is : " + x.totalTime);
				}
				else{
					System.out.print("Path of Taxi " + availableTaxis.getElement(j).taxiName + " : " );
					System.out.println(tmp[1] + ". " + "Time Taken is : 0");
				}
			}
			System.out.println(" ");
			}
			else{
				System.out.println("Please put the correct stations");
			}*/
			/*int kil = 1000;
			Taxi best = new Taxi(null, null, 0);
			int timeCust = Integer.parseInt(tmp[3]);
			if(positionSet.findPosition(tmp[1])!=null && positionSet.findPosition(tmp[2])!=null){
			for(int i=0;i<positionSet.ridam.getSizeSet();i++){
				if(positionSet.ridam.getElement(i).thisPosition.equals(tmp[1])){
					//System.out.println("if me aa gya");
					
					System.out.println("Available Taxis : ");
					
					for(int j=0;j<taxiSet.setOfAllTaxis.getSizeSet();j++){
						//System.out.println("for me aa gya");
						Myset<Taxi> setOfAvailableTaxis = new Myset<Taxi>();
						if(taxiSet.setOfAllTaxis.getElement(j).availability<timeCust){
						setOfAvailableTaxis.addElement(taxiSet.setOfAllTaxis.getElement(j)); 
						pathSet.mainFunction(taxiSet.setOfAllTaxis.getElement(j).currPosition);
						Myset<Position> cf = pathSet.getPath(positionSet.ridam.getElement(i));
						System.out.print("Taxi : " + taxiSet.setOfAllTaxis.getElement(j).taxiName + " " + taxiSet.setOfAllTaxis.getElement(j).currPosition.thisPosition + " ");
						
						if(cf!=null){
							for(int k=1;k<cf.getSizeSet()-1;k++){
							System.out.print(cf.getElement(k).thisPosition + ", ");
							}
						}

						System.out.print(positionSet.ridam.getElement(i).thisPosition); 
						System.out.println(". Time Taken is : " + pathSet.getShortestDistance(positionSet.ridam.getElement(i)) + " units.");
						if(kil>pathSet.getShortestDistance(positionSet.ridam.getElement(i))){
							kil = pathSet.getShortestDistance(positionSet.ridam.getElement(i));
							best = taxiSet.setOfAllTaxis.getElement(j);
						}
						
						}
						//System.out.println(best.availability);
					}	
				}
				if(positionSet.ridam.getElement(i).thisPosition.equals(tmp[1])){
					pathSet.mainFunction(positionSet.ridam.getElement(i));
				}
			}
			System.out.println("*** Chose " + best.taxiName + " to service the customer request ***");
			for(int i=0;i<positionSet.ridam.getSizeSet();i++){	
				if(positionSet.ridam.getElement(i).thisPosition.equals(tmp[2])){
					System.out.println("Path of Customer : ");
					
					Myset<Position> cf1 = pathSet.getPath(positionSet.ridam.getElement(i));
					if(cf1!=null){
					for(int k=0;k<cf1.getSizeSet()-1;k++){
						System.out.print(cf1.getElement(k).thisPosition + ", ");
					}
					}
					System.out.print(positionSet.ridam.getElement(i).thisPosition);
					System.out.print(". Time Taken is : " + pathSet.getShortestDistance(positionSet.ridam.getElement(i)) + " units.");
					int gh= pathSet.getShortestDistance(positionSet.ridam.getElement(i));
					//System.out.println(gh);
					/*for(int l=0;l<taxiSet.setOfAllTaxis.getSizeSet();l++){
				System.out.println(taxiSet.setOfAllTaxis.getElement(l).availability);
			}*/	/*System.out.println("");
				System.out.println("Total Time is : " + (gh + kil));
					
					best.availability = gh;
					/*for(int l=0;l<taxiSet.setOfAllTaxis.getSizeSet();l++){
				System.out.println(taxiSet.setOfAllTaxis.getElement(l).availability);
			}
				}*/
				/*for(int l=0;l<taxiSet.setOfAllTaxis.getSizeSet();l++){
				System.out.println(taxiSet.setOfAllTaxis.getElement(l).availability);
			}*/
			/*}
			/*for(int l=0;l<taxiSet.setOfAllTaxis.getSizeSet();l++){
				System.out.println(taxiSet.setOfAllTaxis.getElement(l).availability);
			}*/
			/*}
			for(int bir=0;bir<taxiSet.setOfAllTaxis.getSizeSet();bir++){
				if(best.taxiName.equals(taxiSet.setOfAllTaxis.getElement(bir).taxiName)){
					//System.out.println(kil);
					//System.out.println(best.availability);
					//System.out.println(taxiSet.setOfAllTaxis.getElement(bir).availability);
					taxiSet.setOfAllTaxis.getElement(bir).availability += timeCust + kil;
					taxiSet.setOfAllTaxis.getElement(bir).currPosition = positionSet.findPosition(tmp[2]);
				}
			}
			/*for(int l=0;l<taxiSet.setOfAllTaxis.getSizeSet();l++){
				System.out.println(taxiSet.setOfAllTaxis.getElement(l).availability);
			}*/
			/*}
			else{
				System.out.println("Please Provide Correct inputs");
			}
		}
		if(tmp[0].equals("printTaxiPosition")){
			int timer = Integer.parseInt(tmp[1]);
			for(int i=0;i<taxiSet.setOfAllTaxis.getSizeSet();i++){
				if(taxiSet.setOfAllTaxis.getElement(i).availability<=timer){
					System.out.println("Taxi " + taxiSet.setOfAllTaxis.getElement(i).taxiName + ": " + taxiSet.setOfAllTaxis.getElement(i).currPosition.thisPosition);
				}
			}
		}*/
	}
}
