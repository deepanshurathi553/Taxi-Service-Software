import java.util.*;
public class Edge{
		
	Position start;
	Position end;
	int time;	

	public Edge(Position x, Position y, int t){
		start = x;
		end = y;
		time = t;
	}

}