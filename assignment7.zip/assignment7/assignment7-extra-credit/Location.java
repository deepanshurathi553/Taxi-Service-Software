import java.util.*;

public class Location{
	Position vertexStart;
	Position vertexEnd;
	int distance;

	public Location(Position x, Position y, int t){
		vertexStart = x;
		vertexEnd =y;
		distance = t;
	}
}